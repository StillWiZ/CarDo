package com.example.carApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
