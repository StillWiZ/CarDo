import 'package:flutter/material.dart';

const MainHeading = TextStyle(fontWeight: FontWeight.bold, fontSize: 30);

const SubHeading = TextStyle(fontWeight: FontWeight.bold, fontSize: 20);

const BasicHeading = TextStyle(fontSize: 15);
